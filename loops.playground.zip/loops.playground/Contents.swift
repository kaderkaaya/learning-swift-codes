//for i in 1...100 {
   // print("Number \(i)")
//}
var numbers = [1,3,5,7,17,11,9,1,6]
for (indexNum,num )in numbers.enumerated(){
    print("Number :\(num), İndexNum: \(indexNum)")
}
