import UIKit

var greeting:String = "Hello,"
let pi :Float = 3.14
var bosluk :String
let bossabit :Int
let isim ="kader"
greeting= "merhaba,"

print(greeting+isim)
print("hello, \(isim)" )
